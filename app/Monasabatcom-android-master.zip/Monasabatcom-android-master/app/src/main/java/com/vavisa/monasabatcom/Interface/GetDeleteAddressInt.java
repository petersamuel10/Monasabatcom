package com.vavisa.monasabatcom.Interface;

public interface GetDeleteAddressInt {
    void onDeleteAddressError(String message);

    void onDeleteAddressSuccess(String user);
}
