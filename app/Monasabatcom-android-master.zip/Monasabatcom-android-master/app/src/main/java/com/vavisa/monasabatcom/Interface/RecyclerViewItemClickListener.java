package com.vavisa.monasabatcom.Interface;

import android.view.View;

public interface RecyclerViewItemClickListener {
    public void onItemClick(int position, int flag, View view);
}
