package com.vavisa.monasabatcom.Interface;

public interface GetEditAddressInt {
    void onEditAddressError(String message);

    void onEditAddressSuccess(String user);
}
